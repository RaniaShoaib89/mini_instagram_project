
#include "User.h"
#include "Graph.h"
#include <iostream>
#include <string>
#include <algorithm>
#include <string>
using namespace std;





User::User(string u, string p, string city = "", bool isPublic = true)
{
	this->username = u;
	this->password = p;
	this->city = city;
	this->lastLogin = time(0);
	this->isPublic = isPublic;
}

string User::getUserName(){ return username; }

//string User::getName() { return name; }
//string User::getEmail(){ return email; }

void User::setUsername(string x) { username = x; };
//void User::setName(string x) { name = x; };
//void User::setEmail(string x) { email = x; };



//string User::getBio(){	return bio; }

string User::getPassword() {	return password; }
//string User::getPhoneNumber(){ return phoneNumber; }

void User::setPassword(string x) { password = x; };

bool User::is_Public()
{
	return isPublic;
}
//void User::setBio(string x) { bio = x; };
//void User::setPhoneNumber(string x) { phoneNumber = x; };
//
//
//string User::getJoinDate() { return joinDate;}
//string User::getGender() { return gender;}
//int User::getAge() { return age;}
//
//void User::setAge(int x) { age = x; };
//void User::setGender(string x) { gender = x; };
//void User::setJoinDate(string x) { joinDate = x; };


//istream& operator>>(istream& in, User& obj)
//{
//	cout << "Enter name: " << endl;
//	 getline(cin >> ws, obj.name);
//	 cout << "Enter username name: ";
//	 getline(cin >> ws, obj.username);
//
//	bool validEmail = false;
//	while (!validEmail) {
//		cout << "Enter Email Address: ";
//		getline(cin >> ws, obj.email);
//
//
//		if (obj.email.find('@') != string::npos) {
//			validEmail = true;
//		}
//		else {
//			cout << "Invalid email address.\nMust include '@' in email address." << endl;
//		}
//	}
//
//
//	cout << "Enter password: " << endl;
//	getline(cin >> ws, obj.password);
//	cout << "Enter age: ";
//	cin >> obj.age;
//	cout << "Enter bio: " << endl;
//	getline(cin >> ws, obj.bio);
//	cout << "Enter gender: " << endl;
//	getline(cin >> ws, obj.gender);
//
//
//
//
//	bool validPhoneNumber = false;
//	while (!validPhoneNumber) {
//		cout << "Enter phone number (exactly 11 digits): ";
//		getline(cin >> ws, obj.phoneNumber);
//
//		if (obj.phoneNumber.length() == 11 &&
//			all_of(obj.phoneNumber.begin(), obj.phoneNumber.end(), ::isdigit))
//		{
//			validPhoneNumber = true;
//		}
//		else
//		{
//			cout << "Invalid phone number.\nEnter exactly 11 digits." << endl;
//		}
//	}
//
//
//
//	cout << "Enter join date: " << endl;
//	getline(cin >> ws, obj.joinDate);
//
//
//
//	return in;
//
//
//}
//
//ostream& operator<<(ostream& out, User& obj)
//{
//	out << "name: " << obj.name << endl;
//	out << "username: " << obj.username << endl;
//	out << "email address: " << obj.email << endl;
//	out << "password: " << obj.password<< endl;
//	out << "bio: " << obj.bio << endl;
//	out << "Gender: " << obj.gender<< endl;
//	out << "Age: " << obj.age << endl;
//	out << "phone number: " << obj.phoneNumber << endl;
//	out << "join date: " << obj.joinDate << endl;
//
//
//	return out;
//
//
//}



