#include <string>
#pragma once
#define MESSAGE_H

using namespace std;


class Message
{
public:

    string sender;
    string receiver;
    string content;
    time_t timestamp;


};

