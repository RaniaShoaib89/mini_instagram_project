#include <string>
#include <ctime>

#pragma once
#define USER_H


using namespace std;



class User
{
private:

	bool isPublic;
	string username;
	//string email;
	//string name;
	string password;
	//string bio;
	//string phoneNumber;
	//string joinDate;
	//string gender;
	//int age;
	long lastLogin;
	string city;

	//friend istream& operator>>(istream& in, User& obj);
	//friend ostream& operator<<(ostream& in, User& obj);

public:
	User(string u, string p, string city, bool isPublic);
	string getUserName();
	//string getName();
	//string getEmail();
	void setUsername(string x);
	//void setName(string x);
	//void setEmail(string x);
	bool is_Public();
	
	string getPassword();
	//string getBio();
	//string getPhoneNumber();
	void setPassword(string x);
	//void setBio(string x);
	//void setPhoneNumber(string x);


	//string getJoinDate();
	//string getGender();
	//int getAge();
	//void setJoinDate(string x);
	//void setGender(string x);
	//void setAge(int x);

	
	User(const User& other) {
		username = other.username;
		//email = other.email;
		//name = other.name;
		password = other.password;
		//bio = other.bio;
		//phoneNumber = other.phoneNumber;
		////joinDate = other.joinDate;
		//gender = other.gender;
		//age = other.age;
		//lastLogin = other.lastLogin;
		city = other.city;
		isPublic = this->isPublic;
	}

	// Assignment operator (optional, but good practice)
	User& operator=(const User& other) {
		if (this != &other) {
			username = other.username;
			//email = other.email;
			//name = other.name;
			password = other.password;
			//bio = other.bio;
			//phoneNumber = other.phoneNumber;
			//joinDate = other.joinDate;
			//gender = other.gender;
			//age = other.age;
			//lastLogin = other.lastLogin;
			city = other.city;
			isPublic = this->isPublic;
		}
		return *this;
	}


	bool operator==(const User& other)
	{
		return (password == other.password && username == other.username && isPublic == other.isPublic);
	}






	

};

